import pandas as pd
import matplotlib.pyplot as plt
import numpy as np



# Read the datasets
try:
    data_A = pd.read_csv('targetA.csv')
except:
    print("Error Loading TargetA File")

try:
    data_B = pd.read_csv('targetB.csv')
except:
    print("Error Loading TargetB File")
    
# Plot sequence numbers over time (Graph1)
plt.figure(figsize=(10, 5))
plt.plot(data_A ['Time'], data_A ['No.'], label='targetA.csv')
plt.xlabel('Time')
plt.ylabel('Sequence Numbers')
plt.title('Sequence Numbers Over Time')
plt.legend()
plt.grid(True)
plt.show()

# Determine the range and bin size for packet lengths
min_length = data_A['Length'].min()
max_length = data_A['Length'].max()
bin_width = 50  # Adjust the bin width to scale the x-axis appropriately

# Create bins and bin the packet lengths
bins = np.arange(min_length, max_length + bin_width, bin_width)
binned_packet_lengths = pd.cut(data_A['Length'], bins=bins, include_lowest=True)

# Calculate probabilities for each bin
probabilities = binned_packet_lengths.value_counts(normalize=True).sort_index()

# Convert bin labels to string so they can be used as x-tick labels
bin_labels = [f"{int(left)}-{int(right)}" for left, right in zip(bins[:-1], bins[1:])]

# Plot probabilities of binned packet lengths
plt.figure(figsize=(10, 5))  # Adjust figure size
plt.bar(bin_labels, probabilities, color='skyblue')
plt.xlabel('Packet Length Bins')
plt.ylabel('Probability')
plt.title('Probabilities of Binned Packet Lengths')
plt.xticks(rotation=90)  # Rotate labels for better readability, use 90 to have vertical labels
plt.grid(axis='y')
plt.tight_layout()  # Adjust layout to prevent clipping of labels
plt.show()

# Calculate mean, mode, and standard deviation of packet length
mean_length = data_A['Length'].mean()
mode_length = data_A['Length'].mode().values[0]
std_dev_length = data_A['Length'].std()

print("Mean of packet length:", mean_length)
print("Mode of packet length:", mode_length)
print("Standard deviation of packet length:", std_dev_length)

# Plot cumulative distribution function (CDF) and probability density function (PDF) of packet lengths
# PDF Plot
plt.figure(figsize=(10, 5))
plt.hist(data_A['Length'], bins=20, density=True, cumulative=False, 
         histtype='step', label='PDF', color='orange')
plt.xlabel('Packet Length')
plt.ylabel('Probability Density')
plt.title('PDF of Packet Lengths')
plt.legend()
plt.grid(True)
plt.show()

# CDF Plot
plt.figure(figsize=(10, 5))
plt.hist(data_A['Length'], bins=20, density=True, cumulative=True, 
         histtype='step', label='CDF', color='blue')
plt.xlabel('Packet Length')
plt.ylabel('Cumulative Probability')
plt.title('CDF of Packet Lengths')
plt.legend()
plt.grid(True)
plt.show()

# Calculate and plot packet delays
packet_delays = data_A['Time'] - data_B['Time']
plt.figure(figsize=(10, 5))
plt.plot(packet_delays, label='Packet Delays')
plt.xlabel('Packet Number')
plt.ylabel('Delay (seconds)')
plt.title('Packet Delays from A to B')
plt.legend()
plt.grid(True)
plt.show()
