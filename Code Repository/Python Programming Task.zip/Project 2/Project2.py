import matplotlib.pyplot as plt
import numpy as np

class Student:
    def __init__(self, student_id, name, address):
        """
        Initializes a Student object with a student ID, name, and address.
        """
        self.student_id = student_id
        self.name = name
        self.address = address
        self.grades_digital = None
        self.grades_programming = None

    def set_grades_digital(self, grades_digital):
        """
        Sets the digital grades for the student.
        """
        self.grades_digital = grades_digital

    def set_grades_programming(self, grades_programming):
        """
        Sets the programming grades for the student.
        """
        self.grades_programming = grades_programming

    def get_average_grade(self):
        """
        Calculates the average grade for the student across all modules.
        """
        grades = []
        if self.grades_digital is not None:
            grades.extend(self.grades_digital.values())
        if self.grades_programming is not None:
            grades.extend(self.grades_programming.values())
        if grades:  # Check if list is not empty
            return sum(grades) / len(grades)
        else:
            return None
    def add_or_update_grade_digital(self, grade):
        """
        Adds or updates a digital grade.
        """
        if self.grades_digital is None:
            self.grades_digital = {}
        self.grades_digital['digital'] = grade

    def add_or_update_grade_programming(self, grade):
        """
        Adds or updates a programming grade.
        """
        if self.grades_programming is None:
            self.grades_programming = {}
        self.grades_programming['programming'] = grade
        

class StudentDatabase:
    def __init__(self):
        """
        Initializes a StudentDatabase object to manage student records.
        """
        self.students = {}

    def load_student_data(self, filename):
        """
        Loads student data from a file and populates the database.
        """
        with open(filename, 'r') as file:
            for line in file:
                student_info = line.strip().split()
                student_id = student_info[0]
                name = ' '.join(student_info[1:-5])
                address = ' '.join(student_info[-5:])
                self.students[student_id] = Student(student_id, name, address)

    def load_grades_digital(self, filename):
        """
        Loads digital grades from a file and assigns them to respective students.
        """
        with open(filename, 'r') as file:
            for line in file:
                student_id, grade = line.strip().split()
                if student_id in self.students:
                    if self.students[student_id].grades_digital is None:
                        self.students[student_id].grades_digital = {}
                    self.students[student_id].grades_digital['digital'] = int(grade)

    def load_grades_programming(self, filename):
        """
        Loads programming grades from a file and assigns them to respective students.
        """
        with open(filename, 'r') as file:
            for line in file:
                student_id, grade = line.strip().split()
                if student_id in self.students:
                    if self.students[student_id].grades_programming is None:
                        self.students[student_id].grades_programming = {}
                    self.students[student_id].grades_programming['programming'] = int(grade)

    def collect_all_grades(self):
        """Collects all grades from both modules for all students."""
        grades = []
        for student in self.students.values():
            if student.grades_digital:
                grades.extend(list(student.grades_digital.values()))
            if student.grades_programming:
                grades.extend(list(student.grades_programming.values()))
        return grades

    def add_student(self, student):
        """
        Adds a new student to the database.
        """
        self.students[student.student_id] = student

    def remove_student(self, student_id):
        """
        Removes a student from the database.
        """
        if student_id in self.students:
            del self.students[student_id]

    def modify_student_data(self, student_id, attribute, new_value):
        """
        Modifies the Name or Address of student.
        """
        if student_id in self.students:
            student = self.students[student_id]
            if hasattr(student, attribute):
                setattr(student, attribute, new_value)
                print("Attribute updated successfully.")
            else:
                print("Invalid attribute name.")
        else:
            print("Student not found.")

    def plot_grade_distribution(self):
        """
        Plots the grade distribution for both modules.
        """
        digital_grades = []
        programming_grades = []

        for student_id, Student in self.students.items():
            for student_id, student in self.students.items():
                        if student.grades_digital:
                            digital_grade = next(iter(student.grades_digital.values()))
                            digital_grades.append(digital_grade)

                        if student.grades_programming:
                            programming_grade = next(iter(student.grades_programming.values()))
                            programming_grades.append(programming_grade)
                    # Set the number of bins for the histogram
        bins = range(0, 101, 10)
        
        #digital grades
        plt.figure(figsize=(10, 5))
        plt.hist(digital_grades, bins=np.arange(0, 101, 10), alpha=0.5, color='blue', label='Digital Grades')
        plt.xlabel('Grades')
        plt.ylabel('Percentage of Students')
        plt.title('Distribution of Digital Grades')
        plt.legend()
        plt.grid(True)
        plt.yticks(ticks=plt.yticks()[0], labels=[f"{y:.1f}" for y in plt.yticks()[0]]) 
        plt.show()
        #Programming Grades
        plt.figure(figsize=(10, 5))
        plt.hist(programming_grades, bins=np.arange(0, 101, 10), alpha=0.5, color='orange', label='Programming Grades')
        plt.xlabel('Grades')
        plt.ylabel('Percentage of Students')
        plt.yticks(ticks=plt.yticks()[0], labels=[f"{y:.1f}" for y in plt.yticks()[0]])
        plt.title('Unique Distribution of Programming Grades')
        plt.legend()
        plt.grid(True)
        plt.show()


    def store_data(self, filename):
        """
        Stores student data along with grades in a file.
        """
        with open(filename, 'w') as file:
            for student in self.students.values():
                file.write(f"{student.student_id} {student.name} {student.address}\t")

                if student.grades_digital is not None:
                    for module, grade in student.grades_digital.items():
                        file.write(f"{module} {grade}\t")

                if student.grades_programming is not None:
                    for module, grade in student.grades_programming.items():
                        file.write(f"{module} {grade}\n")

    def print_student_data(self, student_id):
        """
        Prints data for a specific student.
        """
        if student_id in self.students:
            student = self.students[student_id]
            print("Student ID:", student.student_id)
            print("Name:", student.name)
            print("Address:", student.address)
            print("Digital Grades:", student.grades_digital)
            print("Programming Grades:", student.grades_programming)
        else:
            print("Student not found.")

    def print_average_grade(self, student_id):
        """
     Calculates and prints the average grade for a given student by ID.
        """
        if student_id in self.students:
            average_grade = self.students[student_id].get_average_grade()
        if average_grade is not None:
            print(f"Average grade for student {student_id} is: {average_grade:.2f}")
        else:
            print(f"Grades for student {student_id} are incomplete.")

   
    def plot_pdf(self):
        """
        Plots the Probability Density Function (PDF) for grades of all modules.
        """
        grades = self.collect_all_grades()
        # Utilizing plt.hist() with density=True for PDF, but using it to plot a line chart
        plt.figure(figsize=(6, 4))
        counts, bin_edges, _ = plt.hist(grades, bins=10, density=True, alpha=0.0)  
        pdf = counts / sum(counts)
        plt.plot(bin_edges[:-1], pdf, marker='o', linestyle='-', color='g', label='PDF')
        plt.title('Probability Density Function (PDF)')
        plt.xlabel('Grades')
        plt.ylabel('Density')
        plt.legend()
        plt.grid(True)
        plt.show()

    def plot_cdf(self):
        """
        Plots the Cumulative Distribution Function (CDF) for grades of all modules.
        """
        grades = self.collect_all_grades()
        # Utilizing plt.hist() with cumulative=True for CDF, but plotting it as a line chart
        plt.figure(figsize=(6, 4))
        counts, bin_edges, _ = plt.hist(grades, bins=10, cumulative=True, density=True, alpha=0.0)  
        cdf = np.cumsum(counts) / sum(counts)
        plt.plot(bin_edges[:-1], cdf, marker='o', linestyle='-', color='b', label='CDF')
        plt.title('Cumulative Distribution Function (CDF)')
        plt.xlabel('Grades')
        plt.ylabel('CDF')
        plt.legend()
        plt.grid(True)
        plt.show()
    
    def add_or_update_student_grade_digital(self, student_id, grade):
        """
        Adds or updates a digital grade for a student.
        """
        if student_id in self.students:
            self.students[student_id].add_or_update_grade_digital(grade)
        else:
            print("Student not found.")

    def add_or_update_student_grade_programming(self, student_id, grade):
        """
        Adds or updates a programming grade for a student.
        """
        if student_id in self.students:
            self.students[student_id].add_or_update_grade_programming(grade)
        else:
            print("Student not found.")

    def display_menu(self):
        """
        Display menu options
        """
        print("\nMenu:")
        print("1.  Add A New Student Name + Address")
        print("2.  Remove A Student")
        print("3.  Modify Student Name + Address")
        print("4.  Print Student Data")
        print("5.  Store And Plot Student Data")
        print("6.  Print Average Grade Of A Student")
        print("7.  Plot PDF")
        print("8.  Plot CDF")
        print("9.  Modify/Add Student Digital Grade")
        print("10. Modify/Add student Programming grade")
        print("11. Quit")

    def run_menu(self):
        """
        Run the menu loop
        """
        while True:
            self.display_menu()
            choice = input("Enter your choice: ")

            if choice == '1':
                student_id = input("Enter student ID: ")
                name = input("Enter student name: ")
                address = input("Enter student address: ")
                std = Student(student_id, name, address)
                self.add_student(std)
            elif choice == '2':
                student_id = input("Enter student ID to remove: ")
                self.remove_student(student_id)
            elif choice == '3':
                student_id = input("Enter student ID to modify: ")
                attribute = input("Enter attribute to modify: ")
                new_value = input("Enter new value: ")
                self.modify_student_data(student_id, attribute, new_value)
            elif choice == '4':
                student_id = input("Enter student ID to print: ")
                self.print_student_data(student_id)
            elif choice == '5':
                self.plot_grade_distribution()
                self.store_data("output.txt")
            elif choice == '6':
                student_id = input("Enter student ID to print the average grade: ")
                self.print_average_grade(student_id)
            elif choice == '7':
                self.plot_pdf()
            elif choice == '8':
                self.plot_cdf()
            elif choice == '9':
                student_id = input("Enter student ID to add/update a digital grade: ")
                grade = int(input("Enter the digital grade: "))
                self.add_or_update_student_grade_digital(student_id, grade)
            elif choice == '10':
                student_id = input("Enter student ID to add/update a programming grade: ")
                grade = int(input("Enter the programming grade: "))
                self.add_or_update_student_grade_programming(student_id, grade)
            elif choice == '11':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please try again.")


if __name__ == "__main__":
    database = StudentDatabase()
    database.load_student_data("student_data.txt")
    database.load_grades_digital("gradesdigital.txt")
    database.load_grades_programming("gradesprogramming.txt")
    database.run_menu()

