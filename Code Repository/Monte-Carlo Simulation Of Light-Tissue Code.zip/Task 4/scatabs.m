function [S_3, N_tran_3, N_ref_3, N_abs_3, N_scat_3] = scatabs(N, mu_s, mu_a, t)
    N_tran_3 = 0; % number of transmitted photons
    N_ref_3 = 0; % number of reflected photons
    N_abs_3 = 0; % number of absorbed photons
    N_scat_3 = 0; % number of scattered photons
    
    for i = 1:N
        % Initialize the starting point
        x = 0;
        y = 0;
        
        % Generate a random angle
        alpha = 2 * pi * rand; 
        
        % Flag to track whether the photon is still in the medium
        entered = 1;
        
        while entered == 1 
            % Step size for the photon
            l = -log(rand) / (mu_s + mu_a); 
            x1 = x + l * cos(alpha); % new x-coordinate
            y1 = y + l * sin(alpha); % new y-coordinate

            % Absorption probability
            Pa = mu_a * l; 
            
            % If photon exits through the top (transmitted)
            if y1 >= t
                entered = 0;
                N_tran_3 = N_tran_3 + 1; % Increment transmitted photon count
                plot([x x1], [y y1], 'LineWidth', 2, 'LineStyle', ':');
                break; % Exit the loop for this photon
                
            % If photon exits through the bottom (reflected)
            elseif y1 <= 0
                entered = 0;
                N_ref_3 = N_ref_3 + 1; % Increment reflected photon count
                plot([x x1], [y y1], 'LineWidth', 2, 'LineStyle', ':');
                break; % Exit the loop for this photon
                
            % If photon is absorbed
            elseif rand < Pa
                N_abs_3 = N_abs_3 + 1; % Increment absorbed photon count
                entered = 0;
                plot([x x1], [y y1], 'LineWidth', 2, 'LineStyle', ':');
                break; % Exit the loop for this photon
                
            % If photon scatters
            else
                N_scat_3 = N_scat_3 + 1; % Increment scattering count
                plot([x x1], [y y1], 'LineWidth', 2, 'LineStyle', '-.');
                x = x1; % Update x-coordinate
                y = y1; % Update y-coordinate
                alpha = 2 * pi * rand; % Generate new random angle
            end
        end
    end
    
    % Plot settings
    box on;
    axis tight;
    xlabel('X-axis', 'FontSize', 12);
    ylabel('Y-axis', 'FontSize', 12);
    title(['Thickness = ', num2str(t), ' mm; Scattering coefficient = ', num2str(mu_s), ' mm^-1', ' Absorption coefficient = ', num2str(mu_a), ' mm^-1']);
    
    % Total photons (transmitted, reflected, and absorbed)
    S_3 = N_tran_3 + N_abs_3 + N_ref_3; 
end