%Task 4: photon path through a scattering and absorbing medium
figure; hold on;
mu_a=1; %unit in (1/mm)
mu_s=20; %unit in (1/mm)
t=1; %unit in mm
N=1000; %incident number of photons
[S_3,N_tran_3,N_ref_3,N_abs_3,N_scat_3]=scatabs(N,mu_s,mu_a,t);
display(S_3) %S_2 should be equal to N
hold off;