figure; hold on;
mu_s = 80.81; % unit in (1/mm)
t = 1; % unit in mm
N = 1000; % incident number of photons

% Call the scattering function with the correct input arguments
[S_2, N_tran_2, N_ref_2, N_abs_2] = scattering(N, mu_s, t);

% Display the result
display(S_2) % S_2 should be equal to N
