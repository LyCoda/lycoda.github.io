function[S_2,N_tran_2,N_ref_2,N_abs_2]=scattering(N,mu_s,t)
N_tran_2=0; %number of transmitted photons
N_ref_2=0; %number of reflected photons
N_abs_2=0; %number of absorbed photons
for i=1:N
x=0;
y=0;
N_step=0;
entered=1;
    while entered==1 %photon entered in tissue
        alpha=2*pi*rand; % a random angle generated
        l=-log(rand)/mu_s; %step size calculated
        x1=x+l*cos(alpha); %x-coordinate calcated
        y1=y+l*sin(alpha); %y-coordinate calcated
        if y1>t %conditions for transmittance
            entered=0; %photon transmitted 
            N_tran_2=N_tran_2+1; %transmitted photon number recorded
        elseif y1<0 %conditions for reflectance
            entered=0; %photon transmitted 
            N_ref_2=N_ref_2+1; %reflected photon number recorded
        else
            N_step=N_step+1; %number of steps through tissue
            plot([x x1],[y y1],'Linewidth',2,'Linestyle','-.');
            hold on;
            x=x1; %x-coordinate updated
            y=y1; %y-coordinate update 
        end 
    end
end
box on;
axis tight; 
xlabel('X-axis','FontSize',12);
ylabel('Y-axis','FontSize',12);
title(['Thickness = ',num2str(t),' mm; Scattering coefficient =' num2str(mu_s), ' mm^-^1']);
S_2= N_tran_2+ N_abs_2+ N_ref_2 ; % sum of all transmitted, reflected and absorbed photons
end