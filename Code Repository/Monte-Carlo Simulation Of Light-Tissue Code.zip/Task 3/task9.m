% Task 3: Photon path through a scattering medium at different wavelengths

% Wavelengths in nm
wavelengths = [570, 660, 740, 880, 940]; 

% Pre-allocate arrays for results
N_tran_arr = zeros(1, length(wavelengths));  % Transmitted photons
N_ref_arr = zeros(1, length(wavelengths));   % Reflected photons
S_arr = zeros(1, length(wavelengths));       % Total photons

% Loop over wavelengths
for i = 1:length(wavelengths)
    % Convert wavelength from nm to micrometers (1 nm = 1e-3 μm)
    lambda = wavelengths(i) / 1000;  % Convert to micrometers

    % Calculate scattering coefficient mu_s using the given formula
    mu_s = (2e4 * lambda^(-1.5)) + (2e11 * lambda^(-4)); 

    % Tissue thickness and number of photons
    t = 1;  % thickness in mm
    N = 1000;  % number of incident photons

    % Clear previous global variables (if any)
    clear global N_tran_2 N_ref_2 S_2;
    
    % Run the scattering simulation for this wavelength
    % This will update the global variables: N_tran_2, N_ref_2, S_2
    scattering(N, mu_s, t);
    
    % Store results from the global variables
    global N_tran_2 N_ref_2 S_2;
    N_tran_arr(i) = N_tran_2;  % transmitted photons
    N_ref_arr(i) = N_ref_2;    % reflected photons
    S_arr(i) = S_2;            % total photon sum

    % Plot photon paths for this wavelength (optional)
    figure;
    hold on;
    xlabel('X-axis','FontSize',12);
    ylabel('Y-axis','FontSize',12);
    title(['Wavelength = ', num2str(wavelengths(i)), ' nm; Scattering coefficient = ', num2str(mu_s), ' mm^{-1}']);
end

% Plot the results
figure;
subplot(1,2,1);
plot(wavelengths, N_tran_arr./S_arr, 'b-o', 'LineWidth', 2);
hold on;
plot(wavelengths, N_ref_arr./S_arr, 'r-o', 'LineWidth', 2);
xlabel('Wavelength (nm)');
ylabel('Fraction of photons');
legend('Transmittance', 'Reflectance');
title('Transmittance and Reflectance vs Wavelength');
grid on;

subplot(1,2,2);
plot(wavelengths, N_tran_arr, 'b-o', 'LineWidth', 2);
hold on;
plot(wavelengths, N_ref_arr, 'r-o', 'LineWidth', 2);
xlabel('Wavelength (nm)');
ylabel('Number of Photons');
legend('Transmitted Photons', 'Reflected Photons');
title('Number of Photons Transmitted and Reflected');
grid on;
