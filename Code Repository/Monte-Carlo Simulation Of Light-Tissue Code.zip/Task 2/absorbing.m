function[S,N_tran,N_ref,N_abs]=absorbing(N,mu_a,t)
N_tran=0; %Number of transmitted photons
N_ref=0; %number of reflected photons 
N_abs=0; %number of absorbed photons 
for i=1:N 
    x=0;
    y=0; 
    alpha = 2*pi*rand %a random angle generated 
    N_step=0;
    entered=1;
        while entered ==1 %photon entered in tissue
            l =-log(rand); %step size calculated 
            x1 = x+l *cos(alpha); %x-coordinate calculated
            y1=y+l*sin(alpha); %y-coordinate calculated 
            P=mu_a*l; %Probability of photon absorption 
            if rand<P %conditions for absorption 
                entered = 0; 
                N_abs = N_abs+1; %absorbed photon number recorded
            elseif y1>t %conditions for transmittance 
                entered = 0; %photon transmitted 
                N_tran=N_tran + 1; %transmitted photon number recorded
            elseif y1<0 %conditions for reflectance 
                entered = 0; 
                N_ref = N_ref + 1; %reflected photon number recorded
            else 
                N_step = N_step + 1; %reflected photon number recorded
                plot ([x x1],[y y1],'LineWidth',3);
                hold on; 
                x=x1 %x-coordinate updated
                y=y1; %y-coordinate updated 
            end
        end
end
box on;
axis tight;
xlabel("x Axis", "FontSize",12);
ylabel("y Axis", "FontSize",12);
title(sprintf('Thickness = %.2f mm ; Absorption Coefficient = %.2f mm^{-1}', t, mu_a));

S = sum(N_tran + N_abs + N_ref); % Corrected line
 %sum of all transmitted, reflected and asorbed photons

