%Task 2: Photon Path Through an Absorbing Medium 
figure; hold on;
mu_a = 5.9; %Unit in (1/mm)
t = 1; %unit in mm
N=1000; %Incident number of photons
[S,N_tran,N_ref,N_abs]=absorbing(N,mu_a,t);
display(S) %S Should be Equal to N 
fprintf('Results for mu_a = %d mm^-1:\n', mu_a);
fprintf('Total photons (S): %d\n', S);
fprintf('Transmitted photons (N_tran): %d\n', N_tran);
fprintf('Reflected photons (N_ref): %d\n', N_ref);
fprintf('Absorbed photons (N_abs): %d\n', N_abs);
fprintf('--------------------------\n');
%Task 11: Absorption Coefficient Of Hydrated Skin Tissue
mu_a_water = 15; %absorption coefficient (mm^-1)
mu_a_skin = 2; %Absorption Coefficient s(mm^-1)
W = 0.3; %Value of hydrated tissue in avg human
mu_a_hydrated_skin = W * mu_a_water + (1-W) * mu_a_skin;
fprintf('Absorption Cofficient of hydrated skin tissue: %.2fmm^-1\n', mu_a_hydrated_skin);
hold off;